import pandas as pd
import cinema_module as cm

# Variables globales pour le menu
fichier_csv = "../APPLICATION/DATA/etablissements-cinematographiques.csv"
colonnes_numeriques = [
    "population de la commune", "nombre de films programmés", "films Art et Essai",
    "PdM en entrées des films français", "PdM en entrées des films américains",
    "PdM en entrées des films européens", "PdM en entrées des autres films",
    "écrans", "fauteuils", "entrées 2022", "entrées 2021"
]
donnees = None

def menu():
    print("\n===== MENU PRINCIPAL =====")
    print("1 - Charger et nettoyer les données")
    print("2 - Afficher un aperçu des données")
    print("3 - Compter et traiter valeurs manquantes")
    print("4 - Calculs statistiques")
    print("5 - Afficher graphiques")
    print("0 - Quitter")
    choix = input("Entrez votre choix : ")
    return choix

while True:
    choix = menu()

    if choix == "1":
        print("Chargement et nettoyage...")
        donnees = cm.charger_et_nettoyer(fichier_csv, colonnes_numeriques)
        cm.remplacer_valeurs_manquantes(donnees, colonnes_numeriques, 0)
        print("Données chargées et nettoyées.")

    elif choix == "2":
        if donnees:
            cm.afficher_aperçu(donnees, 5)
        else:
            print("Données non chargées, choisissez option 1.")

    elif choix == "3":
        if donnees:
            manquants = cm.compter_valeurs_manquantes(donnees, colonnes_numeriques)
            print("Valeurs manquantes par colonne :")
            for col, nb in manquants.items():
                print(f"  {col}: {nb}")
        else:
            print("Données non chargées, choisissez option 1.")

    elif choix == "4":
        if donnees:
            print("Statistiques descriptives :")
            for col in colonnes_numeriques:
                moy = cm.moyenne_colonne(donnees, col)
                med = cm.mediane_colonne(donnees, col)
                ecart = cm.ecart_type_colonne(donnees, col)
                mode = cm.mode_colonne(donnees, col)
                print(f"{col} : moyenne={moy}, médiane={med}, écart-type={ecart}, mode={mode}")
            print("\nIndicateurs spécifiques cinéma :")
            print("Taux moyen de fréquentation (entrées 2022 / fauteuils) :", cm.taux_frequentation(donnees))
            print("Pourcentage d'établissements Art et Essai :", cm.pourcentage_art_essai(donnees), "%")
            print("Croissance moyenne des entrées 2021->2022 (%) :", cm.croissance_entre_annees(donnees, "entrées 2021", "entrées 2022"))
            print("Taille moyenne des salles (fauteuils / écrans) :", cm.taille_moyenne_salle(donnees))
            print("Nombre moyen de films programmés par tranche de population :", cm.moyenne_films_par_tranche_population(donnees))
            print("Somme totale des entrées 2022 par région :", cm.somme_entrees_par_region(donnees))
            print("Croissance moyenne des entrées par région (%) :", cm.croissance_entrees_par_region(donnees))
        else:
            print("Données non chargées, choisissez option 1.")

    elif choix == "5":
        if donnees:
            df = pd.DataFrame(donnees)
            cm.histogramme_fauteuils(df)
            cm.barplot_top_regions_par_ecrans(df)
            cm.scatter_fauteuils_vs_entrees(df)
            cm.boxplot_entrees_2022(df)
            cm.barplot_moyenne_films_par_tranche(pd.Series(cm.moyenne_films_par_tranche_population(donnees)).to_frame(name="Moyenne films"))
            cm.barplot_entrees_par_region(cm.somme_entrees_par_region(donnees))
            cm.barplot_croissance_par_region(cm.croissance_entrees_par_region(donnees))
        else:
            print("Données non chargées, choisissez option 1.")

    elif choix == "0":
        print("Au revoir.")
        break

    else:
        print("Choix invalide, veuillez réessayer.")
