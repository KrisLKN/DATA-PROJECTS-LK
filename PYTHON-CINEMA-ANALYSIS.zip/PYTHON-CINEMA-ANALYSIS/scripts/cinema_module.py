import csv
import matplotlib.pyplot as plt
import pandas as pd

# =================== PARTIE 1 : CHARGEMENT & NETTOYAGE ===================

def nettoyer_valeur(val):
    if val is None:
        return None
    val = val.strip()
    if val == "":
        return None
    val = val.replace(",", ".")
    try:
        return float(val)
    except ValueError:
        return None

def charger_et_nettoyer(fichier_csv, colonnes_numeriques):
    donnees = []
    with open(fichier_csv, encoding="utf-8") as f:
        lecteur = csv.DictReader(f, delimiter=";")
        for ligne in lecteur:
            for col in colonnes_numeriques:
                if col in ligne:
                    ligne[col] = nettoyer_valeur(ligne[col])
            donnees.append(ligne)
    return donnees

def afficher_aperçu(donnees, n=5):
    print(f"\n--- Aperçu des {n} premières lignes ---")
    for i, ligne in enumerate(donnees[:n], 1):
        print(f"Ligne {i}: {ligne}")

def compter_valeurs_manquantes(donnees, colonnes):
    compte = {col: 0 for col in colonnes}
    for ligne in donnees:
        for col in colonnes:
            if ligne.get(col) is None:
                compte[col] += 1
    return compte

def remplacer_valeurs_manquantes(donnees, colonnes, valeur_remplacement=0):
    for ligne in donnees:
        for col in colonnes:
            if ligne.get(col) is None:
                ligne[col] = valeur_remplacement

def filtrer_lignes_incomplete(donnees, colonnes_essentielles):
    resultat = []
    for ligne in donnees:
        if all(ligne.get(col) is not None for col in colonnes_essentielles):
            resultat.append(ligne)
    return resultat

# =================== PARTIE 2 : STATISTIQUES ===================

def moyenne_colonne(data, col):
    valeurs = [ligne[col] for ligne in data if ligne.get(col) is not None]
    if not valeurs:
        return None
    return round(sum(valeurs) / len(valeurs), 2)

def mediane_colonne(data, col):
    valeurs = sorted([ligne[col] for ligne in data if ligne.get(col) is not None])
    n = len(valeurs)
    if n == 0:
        return None
    if n % 2 == 1:
        return valeurs[n // 2]
    else:
        return round((valeurs[n // 2 -1] + valeurs[n // 2]) / 2, 2)

def ecart_type_colonne(data, col):
    valeurs = [ligne[col] for ligne in data if ligne.get(col) is not None]
    n = len(valeurs)
    if n < 2:
        return 0.0
    moyenne = sum(valeurs) / n
    variance = sum((x - moyenne) ** 2 for x in valeurs) / (n - 1)
    return round(variance ** 0.5, 2)

def mode_colonne(data, col):
    frequences = {}
    for ligne in data:
        val = ligne.get(col)
        if val is not None:
            frequences[val] = frequences.get(val, 0) + 1
    if not frequences:
        return None
    max_freq = max(frequences.values())
    modes = [val for val, freq in frequences.items() if freq == max_freq]
    return modes if len(modes) > 1 else modes[0]

def taux_frequentation(data):
    taux = []
    for ligne in data:
        fauteuils = ligne.get("fauteuils")
        entrees = ligne.get("entrées 2022")
        if fauteuils and fauteuils != 0 and entrees is not None:
            taux.append(entrees / fauteuils)
    if not taux:
        return None
    return round(sum(taux) / len(taux), 2)

def pourcentage_art_essai(data):
    total = len(data)
    if total == 0:
        return None
    count = sum(1 for ligne in data if ligne.get("films Art et Essai", 0) > 0)
    return round(count / total * 100, 2)

def croissance_entre_annees(data, col_ancien, col_nouveau):
    croissances = []
    for ligne in data:
        val_old = ligne.get(col_ancien)
        val_new = ligne.get(col_nouveau)
        if val_old and val_old != 0 and val_new is not None:
            croissances.append((val_new - val_old) / val_old * 100)
    if not croissances:
        return None
    return round(sum(croissances) / len(croissances), 2)

def taille_moyenne_salle(data):
    ratios = []
    for ligne in data:
        fauteuils = ligne.get("fauteuils")
        ecrans = ligne.get("écrans")
        if fauteuils and ecrans and ecrans != 0:
            ratios.append(fauteuils / ecrans)
    if not ratios:
        return None
    return round(sum(ratios) / len(ratios), 2)

def moyenne_films_par_tranche_population(data):
    tranches = {"<5000": [], "5000-19999": [], "20000-99999": [], ">=100000": []}
    for ligne in data:
        pop = ligne.get("population de la commune")
        films = ligne.get("nombre de films programmés")
        if pop is None or films is None:
            continue
        if pop < 5000:
            tranches["<5000"].append(films)
        elif pop < 20000:
            tranches["5000-19999"].append(films)
        elif pop < 100000:
            tranches["20000-99999"].append(films)
        else:
            tranches[">=100000"].append(films)
    moyennes = {}
    for tranche, vals in tranches.items():
        if vals:
            moyennes[tranche] = round(sum(vals)/len(vals), 2)
        else:
            moyennes[tranche] = None
    return moyennes

def somme_entrees_par_region(data):
    totaux = {}
    for ligne in data:
        region = ligne.get("région administrative", "Inconnu")
        entrees = ligne.get("entrées 2022")
        if entrees is None:
            continue
        totaux[region] = totaux.get(region, 0) + entrees
    return totaux

def croissance_entrees_par_region(data):
    regions = {}
    for ligne in data:
        region = ligne.get("région administrative", "Inconnu")
        ent_21 = ligne.get("entrées 2021")
        ent_22 = ligne.get("entrées 2022")
        if ent_21 is None or ent_21 == 0 or ent_22 is None:
            continue
        if region not in regions:
            regions[region] = {"ent_21":0, "ent_22":0}
        regions[region]["ent_21"] += ent_21
        regions[region]["ent_22"] += ent_22
    croissances = {}
    for region, vals in regions.items():
        taux = (vals["ent_22"] - vals["ent_21"]) / vals["ent_21"] * 100
        croissances[region] = round(taux, 2)
    return croissances

# =================== PARTIE 3 : GRAPHIQUES ===================

def histogramme_fauteuils(df, bins=30):
    plt.figure(figsize=(8,5))
    df['fauteuils'].dropna().plot.hist(bins=bins, edgecolor='black')
    plt.title("Histogramme du nombre de fauteuils par établissement")
    plt.xlabel("Nombre de fauteuils")
    plt.ylabel("Nombre d'établissements")
    plt.grid(axis='y')
    plt.show()

def barplot_top_regions_par_ecrans(df, top_n=10):
    series = df.groupby('région administrative')['écrans'].sum().sort_values(ascending=False).head(top_n)
    plt.figure(figsize=(10,6))
    series.plot(kind='bar')
    plt.title(f"Top {top_n} régions par nombre total d'écrans")
    plt.xlabel("Région")
    plt.ylabel("Nombre total d'écrans")
    plt.xticks(rotation=45, ha='right')
    plt.grid(axis='y')
    plt.show()

def scatter_fauteuils_vs_entrees(df):
    plt.figure(figsize=(8,6))
    plt.scatter(df['fauteuils'], df['entrées 2022'], alpha=0.6, edgecolors='k')
    plt.title("Relation entre nombre de fauteuils et entrées 2022")
    plt.xlabel("Nombre de fauteuils")
    plt.ylabel("Entrées 2022")
    plt.grid(True)
    plt.show()

def boxplot_entrees_2022(df):
    plt.figure(figsize=(6,5))
    plt.boxplot(df['entrées 2022'].dropna())
    plt.yscale('log')  # mettre l'axe Y en échelle logarithmique
    plt.title("Boxplot des entrées 2022 (échelle logarithmique)")
    plt.ylabel("Nombre d'entrées (log)")
    plt.grid(True, which="both", ls="--")  # grille adaptée à l'échelle log
    plt.show()


def barplot_moyenne_films_par_tranche(df):
    plt.figure(figsize=(8,5))
    df.plot.bar()
    plt.title("Nombre moyen de films programmés par tranche de population")
    plt.xlabel("Tranche de population")
    plt.ylabel("Nombre moyen de films programmés")
    plt.grid(axis='y')
    plt.show()

def barplot_entrees_par_region(dico):
    series = pd.Series(dico).sort_values(ascending=False)
    plt.figure(figsize=(10,6))
    series.plot(kind='bar')
    plt.title("Entrées totales 2022 par région")
    plt.xlabel("Région")
    plt.ylabel("Nombre total d'entrées")
    plt.xticks(rotation=45, ha='right')
    plt.grid(axis='y')
    plt.show()

def barplot_croissance_par_region(dico):
    series = pd.Series(dico).sort_values(ascending=False)
    plt.figure(figsize=(10,6))
    series.plot(kind='bar', color='orange')
    plt.title("Croissance moyenne des entrées 2021-2022 par région (%)")
    plt.xlabel("Région")
    plt.ylabel("Croissance en %")
    plt.xticks(rotation=45, ha='right')
    plt.grid(axis='y')
    plt.show()
